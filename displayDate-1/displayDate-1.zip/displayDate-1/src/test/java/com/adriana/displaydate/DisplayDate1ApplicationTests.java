package com.adriana.displaydate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisplayDate1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
